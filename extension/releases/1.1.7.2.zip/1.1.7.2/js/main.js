 yifyApp.Router = Backbone.Router.extend({
   event: event,
   routes: {
     "": "info"
   },

   initialize: function() {
   },
   info: function() {
    $('#spinner').show();

     console.log('#info');
     var lastTorrent = new yifyApp.models.Torrent();
     lastTorrent.fetchLatest({
      success: function(torrent){
        //retrieve torrent details
        lastTorrent.fetchDetails({
          id: torrent.toJSON().MovieList[0].MovieID,
          success: function(details){
            app.changePage(new yifyApp.views.Info({torrent: details.toJSON()}));
          }
        });
        
      }
     });
   },

   changePage: function(page) {
     $(page.el).attr('data-role', 'page');
     page.render();

     $('.container').append($(page.el));
}
});

 $(document).ready(function() {
   console.log('document ready');
   yifyApp.utils.TemplateUtils.loadTemplates([
     'info'
     ],function(){
      app = new yifyApp.Router();
      Backbone.history.start();

     }
     );
 });
