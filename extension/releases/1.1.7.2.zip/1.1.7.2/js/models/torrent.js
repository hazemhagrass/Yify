yifyApp.models.Torrent = Backbone.Model.extend({
	urlRoot: 'http://yify-torrents.com/api/',

	fetchLatest: function(options){
		options = options || {};
		options.url = this.urlRoot + "list.json?limit=1&sort=date&order=desc";

		return Backbone.Model.prototype.fetch.call(this, options);
	},

	fetchDetails: function(options){
		options = options || {};
		options.url = this.urlRoot + "movie.json?id=" + options.id;
		
		return Backbone.Model.prototype.fetch.call(this, options);
	}

});
