var tickTime = 60000;

setInterval(function() {
	$.ajax({
		url: "http://hazemhagrass.com:8091",
	}).done(function(res) {
		var data = $.parseJSON(res);
		if(localStorage.getItem(data.torrent_url) == "seen"){
			//notification seen before
			return;
		}
		//mark torrent url as seen before via localStorage
		localStorage.setItem(data.torrent_url, "seen");

		var notification = window.webkitNotifications.createNotification(
	    data.poster_url,                      // The image.
	    data.title, // The title.
	    'Genre: ' + data.genre + ',Size:' + data.size +
	    ', Quality: ' + data.quality + ', Resolution: ' + data.resolution + 
	    ', Language: ' + data.language + ', IMDB Rating: '+ data.IMDB_rating + 
	    ', Frame Rate: ' + data.frame_rate + ', Peers/Seeds: ' + data.peers_seeds 
	    );
	    notification.onclick = function(){
		    chrome.windows.create({url: data.torrent_url});
		};

		notification.show();
	});
}, tickTime);