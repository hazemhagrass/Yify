 var yifyApp = {
 	models: {},
 	views: {},
 	collections: {},
 	utils: {},
 	locale: "en", 
 	strings: {}
 };