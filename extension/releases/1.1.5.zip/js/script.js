$(document).ready(function(){
	$('#spinner').show();
	$.ajax({
		url: "http://hazemhagrass.com:8091",
	}).done(function(res) {
		var data = $.parseJSON(res);
		updateTorrentData(data);
		updateInfoColors(data);
		$('#spinner').hide();
		$('.container').show();
	});

	function limitText(text, limit){
		if(text.length > limit) text = text.substring(0,limit) + '....';
		return text;	
	}
	function updateTorrentData(data){
		$('.torrent-poster').attr('src', data.poster_url);
		$('.torrent-name').html(data.title);

		$('.visit').attr('href', data.torrent_url);
		$('.download').attr('href', data.download_link);

		$('.torrent-desc').html(limitText(data.desc, 250));
		$('.torrent-genre').html(data.genre);
		$('.torrent-size').html(data.size);
		$('.torrent-quality').html(data.quality);
		$('.torrent-resolution').html(data.resolution);
		$('.torrent-frame-rate').html(data.frame_rate);
		$('.torrent-language').html(data.language);
		$('.torrent-imdb').html(data.IMDB_rating);
		$('.torrent-peers_seeds').html(data.peers_seeds);
		// $('.torrent-uploaded').html(data.uploaded);
		$('.torrent-downloaded').html(data.downloaded);
	}
	
	function updateInfoColors(data){
		var rate = data.IMDB_rating.slice(0, data.IMDB_rating.indexOf('/'));
		if(rate <= 6)
			$('.torrent-imdb').css('color', 'red');
		else if(rate <= 7.5)
			$('.torrent-imdb').css('color', 'rgb(255, 122, 0)');
		else 
			$('.torrent-imdb').css('color', 'green');
	}

	
});


