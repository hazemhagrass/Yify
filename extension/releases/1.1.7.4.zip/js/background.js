var tickTime = 60000;

setInterval(function() {
	$.ajax({
		url: "http://hazemhagrass.com:8091",
	}).done(function(res) {
		var data = $.parseJSON(res);
		if(localStorage.getItem(data.torrent_url) == "seen"){
			//notification seen before
			return;
		}
		//mark torrent url as seen before via localStorage
		localStorage.setItem(data.torrent_url, "seen");

		var id = "yify_" + new Date().getTime();
		var opt = {
			type: "basic",
			title: data.title,
			message: 'Genre: ' + data.genre + ',Size:' + data.size +
				    ', Quality: ' + data.quality + ', Resolution: ' + data.resolution + 
				    ', Language: ' + data.language + ', IMDB Rating: '+ data.IMDB_rating + 
				    ', Frame Rate: ' + data.frame_rate + ', Peers/Seeds: ' + data.peers_seeds ,
			iconUrl: data.poster_url
		}
		chrome.notifications.create(id, opt, function() {
			setTimeout(function() {
				chrome.notifications.clear(id, function() {
					console.log('clear')
				})
			}, 15000);
		});
		chrome.notifications.onClicked.addListener(function(){
		    chrome.windows.create({url: data.torrent_url});
		});

		notification.show();
	});
}, tickTime);