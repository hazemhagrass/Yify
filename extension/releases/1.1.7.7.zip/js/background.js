function checkLatestTorrents(){
	var torrent = new yifyApp.models.Torrent();
	torrent.fetchLatest({
	  limit: 10,
	  success: function(latest){
	    cachedTorrents = latest.toJSON().MovieList;
	    var latestTorrent = cachedTorrents[0];
	    if(localStorage.getItem(latestTorrent.TorrentUrl) == "seen"){
			//notification seen before
			return;
		}
		//mark torrent url as seen before via localStorage
		localStorage.setItem(latestTorrent.TorrentUrl, "seen");

		var id = "yify_" + new Date().getTime();
		var opt = {
			type: "basic",
			title: latestTorrent.MovieTitleClean,
			message:'Year: ' + latestTorrent.MovieYear +
					', Genre: ' + latestTorrent.Genre + 
					', Size:' + latestTorrent.Size +
				    ', Quality: ' + latestTorrent.Quality + 
				    // ', Resolution: ' + latestTorrent.resolution + 
				    //', Language: ' + latestTorrent.Language + 
				    ', IMDB Rating: '+ latestTorrent.MovieRating + 
				    // ', Frame Rate: ' + latestTorrent.frame_rate + 
				    ', Peers/Seeds: ' + latestTorrent.TorrentPeers + "/" + latestTorrent.TorrentSeeds,
			iconUrl: latestTorrent.CoverImage
		}
		var notification = chrome.notifications.create(id, opt, function() {
			setTimeout(function() {
				chrome.notifications.clear(id, function() {
					console.log('clear')
				})
			}, 15000);
		});
		chrome.notifications.onClicked.addListener(function(){
		    chrome.windows.create({url: latestTorrent.TorrentUrl});
		});
	  }
	});
}

var tickTime = 5 * 60000;
setInterval(function() {
	checkLatestTorrents();	
}, tickTime);
checkLatestTorrents();