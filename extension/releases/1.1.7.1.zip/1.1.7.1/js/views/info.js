yifyApp.views.Info = Backbone.View.extend({

	defaults: {
		torrent: null
	},

	initialize:function (args) {
		this.defaults.torrent = args.torrent;
		this.template = _.template(yifyApp.utils.TemplateUtils.get('info'));
	},

	render:function (eventName) {
		$('#spinner').hide();
		$(this.el).html(this.template(this.defaults));
		return this;
	}
});