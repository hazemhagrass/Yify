$(document).ready(function(){

	$.ajax({
		url: "http://hazemhagrass.com:8091",
	}).done(function(res) {
		var data = $.parseJSON(res);
		updateTorrentData(data);
	});

	function updateTorrentData(data){
		$('.torrent-poster').attr('src', data.poster_url);
		$('.torrent-name').html(data.title);
		// $('.torrent-desc').html(data.desc);

		$('.torrent-link').attr('href', data.torrent_url);

		$('.torrent-genre').html(data.genre);
		$('.torrent-size').html(data.size);
		$('.torrent-quality').html(data.quality);
		$('.torrent-resolution').html(data.resolution);
		$('.torrent-frame-rate').html(data.frame_rate);
		$('.torrent-language').html(data.language);
		$('.torrent-imdb').html(data.IMDB_rating);
	}

	
});


